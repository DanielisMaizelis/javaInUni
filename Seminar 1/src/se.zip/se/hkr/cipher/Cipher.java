package se.hkr.cipher;

public interface Cipher
{
    public void encrypt();
    public void decrypt();
}
